describe('Example Web App', () => {
  beforeEach(async () => {
    const filePath = require('path').join(__dirname, '..', 'client', 'index.html');
    await page.goto(`file://${filePath}`);
  });

  it('shows a heading with a title', async () => {
    const heading = await page.$('h1');
    const content = await page.evaluate(el => el.textContent, heading);

    await expect(heading).toBeTruthy();
    await expect(content.length).toBeGreaterThan(1);
  });
});
