console.log("Welcome to the Plan Benchmark Tool!");

let addKeeperBtn = document.querySelector('#add-record-keeper');
let modal = document.querySelector('#modal');
let closeModalBtn = document.querySelector('#closeModal');
let recordKeeperForm = document.querySelector('#record-keeper-form');

function openModal(){
    if (addKeeperBtn) {
        addKeeperBtn.addEventListener('click', function(){
            console.log('Adding record keeper now');
            modal.style.display = 'flex';
        });
    };
};

function closeModal(){
    if(closeModalBtn) {
        closeModalBtn.addEventListener('click', function(){
            console.log('closing record keeper window');
            modal.style.display = 'none';
        });
    };
};

function submitForm() {
    recordKeeperForm.addEventListener('submit', function(event) {
      event.preventDefault(); // prevents page refresh
  
        let keeperId = recordKeeperForm.dataset.editId;
        let isEditing = !!keeperId;

        let nameInput = document.querySelector('#name');
        let numParticipantsInput = document.querySelector('#num_participants');
        let oneTimeCostInput = document.querySelector('#one_time_cost');
        let baseFeeInput = document.querySelector('#base_fee');
        let assetFeeInput = document.querySelector('#asset_fee');
        let participantFeeInput = document.querySelector('#participant_fee');
        let advisorBaseFeeInput = document.querySelector('#advisor_base_fee');
        let advisorFeeInput = document.querySelector('#advisor_fee');
        let otherFeesInput = document.querySelector('#other_fees');
    
        let nameInputValue = nameInput.value;
        let numParticipantsValue = numParticipantsInput.value;
        let oneTimeCostInputValue = oneTimeCostInput.value;
        let baseFeeInputValue = baseFeeInput.value;
        let assetFeeInputValue = assetFeeInput.value;
        let participantFeeInputValue = participantFeeInput.value;
        let advisorBaseFeeInputValue = advisorBaseFeeInput.value;
        let advisorFeeInputValue = advisorFeeInput.value;
        let otherFeesInputValue = otherFeesInput.value;
    
        console.log("Name:", nameInputValue);
        console.log("Number of Participants:", numParticipantsValue);
        console.log("One-Time Cost:", oneTimeCostInputValue);
        console.log("Base Fee:", baseFeeInputValue);
        console.log("Asset Fee:", assetFeeInputValue);
        console.log("Per Participant Fee:", participantFeeInputValue);
        console.log("Advisor Base Fee:", advisorBaseFeeInputValue);
        console.log("Advisor Fee (%):", advisorFeeInputValue);
        console.log("Other Fees:", otherFeesInputValue);
    
        let keeperData = {
            name: nameInputValue,
            num_participants: numParticipantsValue,
            one_time_cost: oneTimeCostInputValue,
            base_fee: baseFeeInputValue,
            asset_fee: assetFeeInputValue,
            participant_fee: participantFeeInputValue,
            advisor_base_fee: advisorBaseFeeInputValue,
            advisor_fee: advisorFeeInputValue,
            other_fees: otherFeesInputValue
        };

        let method = isEditing ? "PUT" : "POST";
        let endpoint = isEditing
        ? `/recordkeepers/${keeperId}`
        : `/recordkeepers`;

        fetch(endpoint, {
        method: method,
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(keeperData)
        })
        .then(function(response) {
            if (!response.ok) {
            console.error("Failed to save record keeper");
            return null;
            }
            return response.json();
        })
        .then(function(savedKeeper) {
            if (!savedKeeper) return;
            console.log("Server saved record keeper:", savedKeeper);

            if (isEditing) {
                let oldBoxId = recordKeeperForm.dataset.oldBoxId;
                if (oldBoxId) {
                  let oldBoxEl = document.getElementById(oldBoxId);
                  if (oldBoxEl) {
                    oldBoxEl.remove();
                  }
                  delete recordKeeperForm.dataset.oldBoxId; 
                }
              }

            createBox(
            savedKeeper.name,
            savedKeeper.num_participants,
            savedKeeper.one_time_cost,
            savedKeeper.base_fee,
            savedKeeper.asset_fee,
            savedKeeper.participant_fee,
            savedKeeper.advisor_base_fee,
            savedKeeper.advisor_fee,
            savedKeeper.other_fees,
            savedKeeper._id
            );

            // 7) Clear editId so next time we do POST by default
            delete recordKeeperForm.dataset.editId;
            recordKeeperForm.reset();
            modal.style.display = "none";
        })
        .catch(function(error) {
            console.error("Error saving record keeper:", error);
        });
  });
}
  

function createBox(
    nameInputValue,
    numParticipantsValue,
    oneTimeCostInputValue,
    baseFeeInputValue,
    assetFeeInputValue,
    participantFeeInputValue,
    advisorBaseFeeInputValue,
    advisorFeeInputValue,
    otherFeesInputValue,
    serverKeeperId
  ) {
    // 1. Create the main box container
    let newBox = document.createElement("div");
    newBox.classList.add("keeper-box");

      // Store the ID for future delete/edit
    if (serverKeeperId) {
        newBox.dataset.keeperId = serverKeeperId;
    }
  
    // 2. Name as a heading
    let nameHeading = document.createElement("h3");
    nameHeading.textContent = nameInputValue;
    newBox.appendChild(nameHeading);

    let pNumParticipants = document.createElement("p");
    pNumParticipants.textContent = "Number of Participants:" + numParticipantsValue;
    newBox.appendChild(pNumParticipants);
  
    // 3. One-Time Cost
    let pOneTime = document.createElement("p");
    pOneTime.textContent = "One-Time Cost: $" + oneTimeCostInputValue;
    newBox.appendChild(pOneTime);
  
    // 4. Base Fee
    let pBase = document.createElement("p");
    pBase.textContent = "Base Fee: $" + baseFeeInputValue;
    newBox.appendChild(pBase);
  
    // 5. Asset Fee
    let pAsset = document.createElement("p");
    pAsset.textContent = "Asset Fee: " + assetFeeInputValue + "%";
    newBox.appendChild(pAsset);
  
    // 6. Per Participant Fee
    let pParticipant = document.createElement("p");
    pParticipant.textContent = "Per Participant Fee: $" + participantFeeInputValue;
    newBox.appendChild(pParticipant);
  
    // 7. Advisor Base Fee
    let pAdvisorBase = document.createElement("p");
    pAdvisorBase.textContent = "Advisor Base Fee: $" + advisorBaseFeeInputValue;
    newBox.appendChild(pAdvisorBase);
  
    // 8. Advisor Fee (%)
    let pAdvisorFee = document.createElement("p");
    pAdvisorFee.textContent = "Advisor Fee: " + advisorFeeInputValue + "%";
    newBox.appendChild(pAdvisorFee);
  
    // 9. Other Fees
    let pOther = document.createElement("p");
    pOther.textContent = "Other Fees: $" + otherFeesInputValue;
    newBox.appendChild(pOther);
  
    // 10. Append to the container
    let container = document.querySelector("#keeper-boxes-container");
    container.appendChild(newBox);

    //button container
    let buttonContainer = document.createElement("div");
    buttonContainer.classList.add("box-buttons");
    newBox.appendChild(buttonContainer);

    // Now time to create a delete button
    let deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Delete";
    deleteBtn.classList.add("delete-btn");
    buttonContainer.appendChild(deleteBtn);

    deleteBtn.addEventListener("click", function() {
        // Get the keeper's ID from newBox.dataset.keeperId
        let keeperId = newBox.dataset.keeperId;
        if (!keeperId) {
          console.error("No ID found on this box. Can't delete from API.");
          return;
        }
      
        // Send DELETE request to server
        fetch(`/recordkeepers/${keeperId}`, {
          method: "DELETE"
        })
          .then(function(response) {
            if (!response.ok) {
              console.error("Failed to delete on server");
              return;
            }
            // If success, remove the box from the DOM
            newBox.remove();
          })
          .catch(function(error) {
            console.error("Error deleting record keeper:", error);
          });
      });

    // Edit button functionality
    let editBtn = document.createElement("button");
    editBtn.textContent = "Edit";
    editBtn.classList.add("edit-btn");
    buttonContainer.appendChild(editBtn);

    editBtn.addEventListener("click", function() {
        let keeperId = newBox.dataset.keeperId;
        if (!keeperId) {
          console.error("No ID found for editing");
          return;
        }
      
        fetch(`/recordkeepers/${keeperId}`)
        .then(function(response) {
          if (!response.ok) {
            console.error("Failed to fetch record keeper for edit");
            return null;
          }
          return response.json();
        })
        .then(function(keeper) {
          if (!keeper) return;
      
            // Pre-fill the modal form fields
            document.querySelector('#name').value = keeper.name;
            document.querySelector('#num_participants').value = keeper.num_participants;
            document.querySelector('#one_time_cost').value = keeper.one_time_cost;
            document.querySelector('#base_fee').value = keeper.base_fee;
            document.querySelector('#asset_fee').value = keeper.asset_fee;
            document.querySelector('#participant_fee').value = keeper.participant_fee;
            document.querySelector('#advisor_fee').value = keeper.advisor_fee;
            document.querySelector('#advisor_base_fee').value = keeper.advisor_base_fee;
            document.querySelector('#other_fees').value = keeper.other_fees;
      
            // Store the ID so we know this is an edit
            recordKeeperForm.dataset.editId = keeper._id;

            newBox.id = "box-" + keeperId;       // set an ID on the box
            recordKeeperForm.dataset.oldBoxId = newBox.id;
      
            // Show the modal
            modal.style.display = "flex";
          })
          .catch(function(error) {
            console.error("Error fetching keeper for edit:", error);
          });
      });
  }

  // registration button 
let registerBtn = document.getElementById('registerBtn');
let registerModal = document.getElementById('register-modal');
let closeRegisterModal = document.getElementById('close-register-modal');

registerBtn.addEventListener('click', function() {
  registerModal.style.display = 'flex';
});

closeRegisterModal.addEventListener('click', function() {
  registerModal.style.display = 'none';
});
  
// registration functionality
let registerForm = document.querySelector('#register-form');

if (registerForm) {
  registerForm.addEventListener('submit', function(event) {
    event.preventDefault();

    let firstName = document.querySelector('#regFirstName').value;
    let lastName = document.querySelector('#regLastName').value;
    let email = document.querySelector('#regEmail').value;
    let password = document.querySelector('#regPassword').value;
    let confirmPassword = document.querySelector('#confirmPassword').value;

    // Check if the passwords match
    if (password !== confirmPassword) {
      console.error("Passwords do not match!");
      // Optionally show an alert or error message on the page
      return;
    }

    // Build the data object with user-entered names
    let data = {
      firstName: firstName,
      lastName: lastName,
      email: email,
      password: password
    };

    // Send a POST request to /users
    fetch('/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
    .then(function(response) {
      if (response.status === 201) {
        return response.json();
      } else {
        throw new Error("Registration failed");
      }
    })
    .then(function(result) {
      console.log("Registration successful! User data:", result);
      registerForm.reset();
      document.querySelector('#register-modal').style.display = 'none';
    })
    .catch(function(error) {
      console.error("Error during registration:", error);
    });
  });
}

// 1. Elements for the login modal
let loginBtn = document.getElementById('loginBtn');
let loginModal = document.getElementById('login-modal');
let closeLoginModal = document.getElementById('close-login-modal');
let loginForm = document.getElementById('login-form');

// 2. Show the login modal when the "Login" button is clicked
if (loginBtn) {
  loginBtn.addEventListener('click', function() {
    loginModal.style.display = 'flex';
  });
}

// 3. Hide the login modal when the close (x) is clicked
if (closeLoginModal) {
  closeLoginModal.addEventListener('click', function() {
    loginModal.style.display = 'none';
  });
}

// 4. Handle the login form submission
if (loginForm) {
  loginForm.addEventListener('submit', function(event) {
    event.preventDefault();
    
    let email = document.querySelector('#loginEmail').value;
    let password = document.querySelector('#loginPassword').value;
    
    // POST request to /login
    fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email, password: password })
    })
    .then(function(response) {
      if (!response.ok) {
        throw new Error("Login failed");
      }
      return response.json();
    })
    .then(function(data) {
      console.log("Login successful:", data);
      // Optionally store user info in local storage, set cookies, etc.
      loginModal.style.display = 'none';
      loginForm.reset();
    })
    .catch(function(error) {
      console.error("Error during login:", error);
    });
  });
}


  










openModal();
closeModal();
submitForm();