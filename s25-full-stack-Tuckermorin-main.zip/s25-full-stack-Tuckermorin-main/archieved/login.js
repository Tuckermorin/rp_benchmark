document.addEventListener('DOMContentLoaded', () => {
  const loginSection = document.querySelector('#loginSection');
  const registerSection = document.querySelector('#registerSection');
  const showRegister = document.querySelector('#showRegister');
  const showLogin = document.querySelector('#showLogin');

  // Toggle to Registration View
  if (showRegister) {
    showRegister.addEventListener('click', (e) => {
      e.preventDefault();
      loginSection.classList.add('hidden');
      registerSection.classList.remove('hidden');
    });
  }

  // Toggle back to Login View
  if (showLogin) {
    showLogin.addEventListener('click', (e) => {
      e.preventDefault();
      registerSection.classList.add('hidden');
      loginSection.classList.remove('hidden');
    });
  }

  // Handle Login Form Submission (placeholder)
  const loginForm = document.querySelector('#login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;
      console.log('Login attempt:', { email, password });
      alert("Login functionality is not connected yet.");
    });
  }

  // Handle Registration Form Submission
  const registerForm = document.querySelector('#register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('regEmail').value;
      const password = document.getElementById('regPassword').value;
      const confirmPassword = document.getElementById('confirmPassword').value;

      if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
      }

      // Build the data object (using placeholder first and last names)
      const data = {
        firstName: "John",
        lastName: "Doe",
        email: email,
        password: password
      };

      try {
        const response = await fetch('/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        });

        if (response.ok) {
          const result = await response.json();
          console.log("Registration successful:", result);
          alert("Registration successful! Please log in.");
          registerForm.reset();
          registerSection.classList.add('hidden');
          loginSection.classList.remove('hidden');
        } else {
          const errorResult = await response.json();
          console.error("Registration failed:", errorResult);
          alert("Registration failed: " + JSON.stringify(errorResult));
        }
      } catch (error) {
        console.error("Error during registration:", error);
        alert("An error occurred during registration.");
      }
    });
  }
});
