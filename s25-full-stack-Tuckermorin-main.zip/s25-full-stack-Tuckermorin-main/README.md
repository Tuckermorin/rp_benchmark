<<<<<<< HEAD
=======
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=17641336)

# SD 6200: JavaScript Web App

This repository contains a **Node/Express** server (`server.js`) and a **client** folder for the front-end of our web application. We have implemented full CRUD (Create, Read, Update, Delete) operations on **record keepers**, including a modal form for adding or editing them, and buttons for deleting them from the UI and the database.

## How to Run
1. Make changes to `server.js` and files in the `client` folder as needed.
2. Click **Run Server** in the status bar (or use your chosen method) to start the server.
3. Open the app in your web browser to interact with the front-end.

## API Endpoints

| **Description**                                                     | **Method** | **Path**                         |
|---------------------------------------------------------------------|-----------|----------------------------------|
| Returns **all** record keepers in JSON format.                      | **GET**    | `/recordkeepers`                 |
| Returns a **single** record keeper by its unique ID.                | **GET**    | `/recordkeepers/:id`             |
| Creates a **new** record keeper.                                    | **POST**   | `/recordkeepers`                 |
| **Edits** an existing record keeper by its unique ID.               | **PUT**    | `/recordkeepers/:id`             |
| **Deletes** a record keeper by its unique ID.                       | **DELETE** | `/recordkeepers/:id`             |

### Request & Response Details
- **GET** `/recordkeepers`:  
  Returns an array of all record keepers.  
  ```json
  [
    {
      "_id": "63f8dabc123456...",
      "name": "401Go",
      "one_time_cost": 500,
      "base_fee": 1320,
      "asset_fee": 0.15,
      ...
    },
    ...
  ]
>>>>>>> abab8f07b26fb3a1a640a36178d18df45a052c7f
