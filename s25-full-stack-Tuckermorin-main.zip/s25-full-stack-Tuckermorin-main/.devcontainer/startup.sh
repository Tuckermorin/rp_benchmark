#!/bin/bash

crumb="$HOME/.codespaces-started"

if [ -f "$crumb" ]; then
  echo -e '\e[1;36mWelcome back to Codespaces!\e[0m\n'
else
  echo -e '\e[1;36mWelcome to Codespaces!\e[0m\n'
  for f in README*.md; do
    if [ -f "$f" ]; then
      code "$f"
    fi
  done
  touch "$crumb"
fi
